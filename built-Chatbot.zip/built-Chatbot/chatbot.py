# chatbot.py

print("🤖 Hello! I'm ChatBuddy. Type 'bye' to exit.")

while True:
    user_input = input("You: ").strip().lower()

    if not user_input:
        print("ChatBuddy: Say something, I'm listening! 😊")
        continue

    if "bye" in user_input:
        print("ChatBuddy: Goodbye! Have a great day! 👋")
        break

    # Greetings
    elif any(greet in user_input for greet in ["hi", "hello", "hey", "good morning", "good evening"]):
        print("ChatBuddy: Hello! How can I assist you today?")

    # Feelings
    elif "how are you" in user_input or "how r u" in user_input:
        print("ChatBuddy: I'm just a bunch of code, but I'm functioning perfectly! 😄")

    elif any(word in user_input for word in ["super", "great", "awesome", "good", "fine"]):
        print("ChatBuddy: Glad to hear that! 😊")

    elif any(word in user_input for word in ["funny", "comedy", "crazy", "good one", "much beter"]):
        print("ChatBuddy: Glad to hear that! 😊")

    elif "sad" in user_input or "not good" in user_input:
        print("ChatBuddy: I'm here if you want to talk about it. Sending good vibes 💛")

    # Name
    elif "your name" in user_input or "who are you" in user_input:
        print("ChatBuddy: I'm ChatBuddy, your simple rule-based chatbot friend!")

    # Capabilities
    elif "can you" in user_input or "what do you know" in user_input or "what can you do" in user_input:
        print("ChatBuddy: I can answer basic questions, tell jokes, talk about weather, and keep you company!")

    # Weather
    elif "weather" in user_input:
        print("ChatBuddy: I can't fetch live data yet, but I hope it's sunny where you are! 🌤️")

    # Jokes
    elif "joke" in user_input:
        print("ChatBuddy: Why did the Python developer go broke? Because he used up all his cache! 😂")

    # Thanks
    elif "thank you" in user_input:
        print("ChatBuddy: You're welcome! 😊")

    # Catch-all
    else:
        print("ChatBuddy: That's interesting! I'm still learning. Try asking something simple like a joke, weather, or how I am.")
