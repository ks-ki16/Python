import os
from PIL import Image

# Input and output folder paths
input_folder = "images"
output_folder = "resized"

# Resize dimensions (width x height)
new_size = (800, 600)

# Ensure the output folder exists
os.makedirs(output_folder, exist_ok=True)

# Supported image formats
allowed_extensions = ('.jpg', '.jpeg', '.png', '.bmp', '.webp')

# Process each image file in the input folder
for filename in os.listdir(input_folder):
    if filename.lower().endswith(allowed_extensions):
        img_path = os.path.join(input_folder, filename)
        print(f"🔄 Processing: {img_path}")  # Show which image is being processed

        try:
            # Open the current image
            img = Image.open(img_path)

            # Resize the image
            img_resized = img.resize(new_size)

            # Save to output folder with the same name (or prefixed)
            save_path = os.path.join(output_folder, f"resized_{filename}")
            img_resized.save(save_path)

            print(f"✅ Saved resized image: {save_path}")
        except Exception as e:
            print(f"❌ Error with {filename}: {e}")
    else:
        print(f"⏩ Skipped (unsupported file): {filename}")
