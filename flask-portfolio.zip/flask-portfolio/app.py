from flask import Flask, render_template, request, flash, redirect, url_for
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = 'your-secret-key-change-this-in-production'

# Sample data for the portfolio
PROJECTS = [
    {
        'title': 'Certificate Generator',
        'description': 'Automates certificate creation using user data and image templates. Built with Flask and Pillow.',
        'technologies': ['Python', 'Flask', 'Pillow', 'HTML', 'CSS'],
        'github': 'https://github.com/ks-ki16/projects-code.git',
        'demo': 'https://cert-generator-demo.netlify.app'
    },
    {
        'title': 'Graphic Design Portfolio',
        'description': 'A digital portfolio showcasing my graphic design and branding projects.',
        'technologies': ['Canva', 'Photoshop', 'HTML', 'CSS'],
        'github': 'https://github.com/muthyala/design-portfolio',
        'demo': 'https://muthyaladesigns.web.app'
    },
    {
        'title': 'ChatBuddy – Simple Chatbot',
        'description': 'A rule-based chatbot using Python with if-else logic to handle simple user queries.',
        'technologies': ['Python', 'Pillow'],
        'github': 'https://github.com/ks-ki16/-Chatbot.git',
        'demo': '#'
    },
    {
        'title': 'Skill Swap Platform (Concept)',
        'description': 'A frontend website prototype for skill-sharing between learners.',
        'technologies': ['HTML', 'CSS', 'JavaScript'],
        'github': 'https://github.com/muthyala/skill-swap',
        'demo': 'https://muthyala-skillswap.vercel.app'
    },
    {
        'title': 'Hotel Booking & IMDB Analysis',
        'description': 'Google Colab notebooks for analyzing hotel booking trends and movie data from IMDB.',
        'technologies': ['Python', 'Pandas', 'Matplotlib', 'Colab'],
        'github': 'https://github.com/ks-ki16/projects-code.git',
        'demo': 'https://colab.research.google.com/drive/your-colab-id'
    }
]

SKILLS = {
    'Programming Languages': ['Python', 'JavaScript', 'HTML/CSS'],
    'Frameworks & Libraries': ['Flask', 'Django', 'React', 'Bootstrap'],
    'Tools & Technologies': ['Photoshop', 'Sketch', 'Figma', 'Canva'],
    'Soft Skills': ['Problem Solving', 'Team Collaboration', 'Project Management']
}

@app.route('/')
def index():
    """Home page with personal information"""
    return render_template('index.html', projects=PROJECTS[:3])

@app.route('/about')
def about():
    """About page with detailed information"""
    return render_template('about.html', skills=SKILLS)

@app.route('/projects')
def projects():
    """Projects page showing all projects"""
    return render_template('projects.html', projects=PROJECTS)

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    """Contact page with form"""
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')
        
        # Basic validation
        if not all([name, email, subject, message]):
            flash('Please fill in all fields.', 'error')
        elif '@' not in email:
            flash('Please enter a valid email address.', 'error')
        else:
            # In a real application, you would send an email or save to database
            # For now, we'll just show a success message
            flash(f'Thank you {name}! Your message has been sent successfully.', 'success')
            return redirect(url_for('contact'))
    
    return render_template('contact.html')

@app.context_processor
def inject_now():
    """Make current year available in all templates"""
    return {'now': datetime.utcnow(), 'current_year': datetime.now().year}

if __name__ == '__main__':
    app.run(debug=True)
